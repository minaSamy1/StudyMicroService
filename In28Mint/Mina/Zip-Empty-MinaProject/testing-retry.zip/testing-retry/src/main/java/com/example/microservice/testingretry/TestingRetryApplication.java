package com.example.microservice.testingretry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestingRetryApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestingRetryApplication.class, args);
	}

}
