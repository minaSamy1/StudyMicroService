package com.example.microservice.testingretry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestingRetryApplicationTests {

	@Test
	void contextLoads() {
	}

}
